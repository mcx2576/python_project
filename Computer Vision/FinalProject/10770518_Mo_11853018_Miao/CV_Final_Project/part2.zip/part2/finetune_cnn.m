function [net, info, expdir] = finetune_cnn(varargin)

%% Define options
% NOTE: my installation path is different than the one given originally,
% the path will depend on map structure of computer where it is runned
%run(fullfile(fileparts(mfilename('fullpath')), ...
%  '..', '..', '..', 'matlab', 'vl_setupnn.m')) ;
run(fullfile(fileparts(mfilename('fullpath')), ...
  'matconvnet-1.0-beta23', 'matlab', 'vl_setupnn.m')) ;   %<--- changed
%main.m is in folder part2, so part2\matconvnet-1.0-beta23\matlab

opts.modelType = 'lenet' ;
[opts, varargin] = vl_argparse(opts, varargin) ;

opts.expDir = fullfile('data', ...
  sprintf('cnn_assignment-%s', opts.modelType)) ;
[opts, varargin] = vl_argparse(opts, varargin) ;

opts.dataDir = './data/' ;
opts.imdbPath = fullfile(opts.expDir, 'imdb-caltech.mat');
opts.whitenData = true ;
opts.contrastNormalization = true ;
opts.networkType = 'simplenn' ;
opts.train = struct() ;
opts = vl_argparse(opts, varargin) ;
if ~isfield(opts.train, 'gpus'), opts.train.gpus = []; end;

%opts.train.gpus = [1];    % <-- changed


%% update model

net = update_model();

%% TODO: Implement getCaltechIMDB function below

if exist(opts.imdbPath, 'file')
  imdb = load(opts.imdbPath) ;
else
  imdb = getCaltechIMDB() ;
  mkdir(opts.expDir) ;
  save(opts.imdbPath, '-struct', 'imdb') ;
end

%%
net.meta.classes.name = imdb.meta.classes(:)' ;

% -------------------------------------------------------------------------
%                                                                     Train
% -------------------------------------------------------------------------

trainfn = @cnn_train ;
[net, info] = trainfn(net, imdb, getBatch(opts), ...
  'expDir', opts.expDir, ...
  net.meta.trainOpts, ...
  opts.train, ...
  'val', find(imdb.images.set == 2)) ;

expdir = opts.expDir;
end
% -------------------------------------------------------------------------
function fn = getBatch(opts)
% -------------------------------------------------------------------------
switch lower(opts.networkType)
  case 'simplenn'
    fn = @(x,y) getSimpleNNBatch(x,y) ;
  case 'dagnn'
    bopts = struct('numGpus', numel(opts.train.gpus)) ;
    fn = @(x,y) getDagNNBatch(bopts,x,y) ;
end

end

function [images, labels] = getSimpleNNBatch(imdb, batch)
% -------------------------------------------------------------------------
images = imdb.images.data(:,:,:,batch) ;
labels = imdb.images.labels(1,batch) ;
if rand > 0.5, images=fliplr(images) ; end

end

% -------------------------------------------------------------------------
function imdb = getCaltechIMDB()
% -------------------------------------------------------------------------
% Preapre the imdb structure, returns image data with mean image subtracted
classes = {'airplanes', 'cars', 'faces', 'motorbikes'};
splits = {'train', 'test'};

%% TODO: Implement your loop here, to create the data structure described in the assignment

% We assume that in each ../CLASS_train and ../CLASS_test folder there are
% .. and .. images respectively named: img001.jpg, ... , img00N.jpg
%
% Caltech4/ImageData/airplanes_train and airplanes_test
% cars_train, faces_train, motorbikes_train

% (k,n) gives num_imgs in class{k} splits{n} 
num_imgs_train_test = [500 50; 465 50; 400 50; 500 50];

img_size = 32;
num_channel = 3;
num_imgs = sum(sum(num_imgs_train_test));

% data = 4D matrix of size (img_height,img_width,num_channel,num_imgs)
data = zeros(img_size,img_size,num_channel,num_imgs,'single');
labels = zeros(1,num_imgs,'single');
sets = zeros(1,num_imgs,'single');

% Go through the 4 classes
index = 1;
for k = 1:4
    cur_class = classes{k};
    for n = 1:2
        if n == 1
            img_folder = sprintf('%s_train',cur_class);
        else
            img_folder = sprintf('%s_test',cur_class);
        end
        
        % load the train/test images
        for i = 1:num_imgs_train_test(k,n)
            img_file = sprintf('../Caltech4/ImageData/%s/img%03d.jpg',img_folder,i);
            img = imread(img_file);
            
            % resize to 32x32x3
            img = imresize(img, [img_size img_size]);
            if size(img,3) == 1
                img = cat(3, img, img, img);
            end
            data(:,:,:,index) = single(img);
            labels(index) = k;
            sets(index) = n;
            index = index + 1;
        end        
    end
end
%data = single(data);
%labels = single(labels);
%sets = single(sets);


%%
% subtract mean
dataMean = mean(data(:, :, :, sets == 1), 4);
data = bsxfun(@minus, data, dataMean);

imdb.images.data = data ;
imdb.images.labels = single(labels) ;
imdb.images.set = sets;
imdb.meta.sets = {'train', 'val'} ;
imdb.meta.classes = classes;

perm = randperm(numel(imdb.images.labels));
imdb.images.data = imdb.images.data(:,:,:, perm);
imdb.images.labels = imdb.images.labels(perm);
imdb.images.set = imdb.images.set(perm);

end
