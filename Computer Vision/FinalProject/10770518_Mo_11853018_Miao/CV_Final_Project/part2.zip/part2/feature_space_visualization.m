function feature_space_visualization

% Load the fine-tuned and pre-trained CNN, and load the data
[net, info, expdir] = finetune_cnn();
nets.fine_tuned = load(fullfile(expdir, 'net-epoch-40.mat')); nets.fine_tuned = nets.fine_tuned.net;
nets.pre_trained = load(fullfile('data', 'pre_trained_model.mat')); nets.pre_trained = nets.pre_trained.net; 
data = load(fullfile(expdir, 'imdb-caltech.mat'));


% We only want the features of the CNN after the last convolutional layer
% Following [X,Y]=get_svm_data(..) returns a struct X so that
% X.features contains the features (64-dim output of last convolutional layer)
% and X.labels contains the labels
nets.pre_trained.layers{end}.type = 'softmax';
nets.fine_tuned.layers{end}.type = 'softmax';
[svm.pre_trained.trainset, svm.pre_trained.testset] = get_svm_data(data, nets.pre_trained);
[svm.fine_tuned.trainset,  svm.fine_tuned.testset] = get_svm_data(data, nets.fine_tuned);


% Want to visualise features from both train and test set,
% so we do 2 runs of tsne:

disp('Visualising features using tsne (pre_trained CNN) in figure1')
% data X
X_pre_trained = [svm.pre_trained.trainset.features; svm.pre_trained.testset.features];
% labels L
L_pre_trained = [svm.pre_trained.trainset.labels; svm.pre_trained.testset.labels];

% Need to convert sparse matrix to dense matrix, since tsne input must be
% dense matrix
X_pre_trained = full(X_pre_trained);

% settings for tsne
no_dims = 2;
initial_dims = 50;
perplexity = 30;
mappedX_pre_trained=tsne(X_pre_trained,L_pre_trained,no_dims,initial_dims,perplexity);
figure(11);
gscatter(mappedX_pre_trained(:,1), mappedX_pre_trained(:,2), L_pre_trained);

disp('pausing  to show result, press button to continue')
pause

disp('Visualising features using tsne (fine_trained CNN) in figure2')
% data X
X_fine_tuned = [svm.fine_tuned.trainset.features; svm.fine_tuned.testset.features];
% labels L
L_fine_tuned = [svm.fine_tuned.trainset.labels; svm.fine_tuned.testset.labels];

% Need to convert sparse matrix to dense matrix, since tsne input must be
% dense matrix
X_fine_tuned = full(X_fine_tuned);

% settings for tsne
no_dims = 2;
initial_dims = 50;
perplexity = 30;
mappedX_fine_tuned=tsne(X_fine_tuned,L_fine_tuned,no_dims,initial_dims,perplexity);
figure(12);
gscatter(mappedX_fine_tuned(:,1), mappedX_fine_tuned(:,2), L_fine_tuned);


end

function [trainset, testset] = get_svm_data(data, net)
trainset.labels = [];
trainset.features = [];

testset.labels = [];
testset.features = [];
for i = 1:size(data.images.data, 4)
    
    res = vl_simplenn(net, data.images.data(:, :,:, i));
    feat = res(end-3).x; feat = squeeze(feat);

    if(data.images.set(i) == 1)
        
        trainset.features = [trainset.features feat];
        trainset.labels   = [trainset.labels;  data.images.labels(i)];
        
    else
        
        testset.features = [testset.features feat];
        testset.labels   = [testset.labels;  data.images.labels(i)];
        
        
    end
    
end

trainset.labels = double(trainset.labels);
trainset.features = sparse(double(trainset.features'));

testset.labels = double(testset.labels);
testset.features = sparse(double(testset.features'));

end